//
//  Merit_add1Tests.swift
//  Merit_add1Tests
//
//  Created by EB209 雲科 on 2025/12/19.
//

import Testing
@testable import Merit_add1

struct Merit_add1Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
