//
//  LevelReward.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2025/12/31.
//

struct LevelReward {
    let level: Int
    let leftReward: String?
    let rightReward: String?
    var isUnlocked: Bool

}
