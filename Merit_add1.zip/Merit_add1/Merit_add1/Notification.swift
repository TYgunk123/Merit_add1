//
//  Notification.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2025/12/30.
//

import Foundation

extension Notification.Name {
    static let favoritesChanged = Notification.Name("favoritesChanged")
}
