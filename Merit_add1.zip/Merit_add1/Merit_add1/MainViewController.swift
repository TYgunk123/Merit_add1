//
//  ViewController.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2025/12/19.
//

import UIKit

class MainViewController: UIViewController {
    @IBOutlet weak var quoteLabel: UILabel!
    
    @IBOutlet weak var tagvalue: UILabel!
    @IBOutlet weak var woodFishImageView: UIImageView!
    var tag = 0
    var level = 0
    var maxcount = 0
    var valuechange = 0//等級改變
    var levelquote = QuoteManager.shared.allQuotes()//等級最大的語錄
    override func viewDidLoad() {
        super.viewDidLoad()
        let quote = QuoteManager.shared.randomQuote(withWoodFishCount: tag)
        quoteLabel.text = quote.text
        
        //點木魚段
        woodFishImageView.image = woodFishImageView.image?
            .withRenderingMode(.alwaysTemplate)

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(updateWoodFish),
            name: .woodFishDidChange,
            object: nil
        )
        
        let tap = UITapGestureRecognizer(//點擊
                target: self,
                action: #selector(woodFishTapped)
            )
            woodFishImageView.isUserInteractionEnabled = true
            woodFishImageView.addGestureRecognizer(tap)
        
        //精選輯資料段
        NotificationCenter.default.addObserver(
                self,
                selector: #selector(handleFavoritesChanged),
                name: .favoritesChanged,
                object: nil
            )
        LevelManager.shared.setupLevels()

        updateWoodFish()
    }
    @objc private func handleFavoritesChanged() {
        let count = QuoteManager.shared.favoriteCount()
        print("收藏更新，目前數量：\(count)")
       
    }
  

    @objc func woodFishTapped() {
        tag+=4
        tagvalue.text="\(tag)"
        showPlusOne()
        SoundManager.shared.playSound(named: "woodfish")
        let result = QuoteManager.shared.randomQuote(
                withWoodFishCount: tag
            )

            quoteLabel.text = result.text
        // 之後你可以加：
        
        if(level < levelquote.endIndex)
        {
            if(maxcount<=levelquote[level].unlockCount )
            {
                maxcount = levelquote[level].unlockCount
                valuechange = 1
            }
            //print(levelquote[level].unlockCount)
            if(tag>=maxcount && valuechange == 1)
            {
                level += 1
                valuechange = 0
                showlevelup(level:level)
            }
        }
        
    }
    func showlevelup(level:Int)
    {
        SoundManager.shared.playSound(named: "levelup")
        LevelManager.shared.updateUnlock(by: level)
        QuoteManager.shared.favoriteQuotes()
        let label = UILabel()
        if(level != levelquote.endIndex)
        {
            label.text = "目前等級 Level:\(level)"
        }
        else
        {
            label.text = "達到最高等級 Level:\(level)"
        }
        label.textColor = .systemGray2
        label.font = UIFont.boldSystemFont(ofSize: 70)
        label.sizeToFit()

        // 初始位置（木魚正中）
        let startX = quoteLabel.center.x
        let startY = quoteLabel.frame.maxY+40
        label.center = CGPoint(x: startX, y: startY)
        label.alpha = 1

        view.addSubview(label)
        label.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
        // 動畫
        UIView.animate(
            withDuration: 0.15,
            delay: 1,
            options: [.curveEaseOut],
            animations: {
                label.transform = .identity
                label.center.y -= 60   // 往上飄
                label.alpha = 0        // 淡出
            },
            completion: { _ in
                label.removeFromSuperview()
            }
        )
    }
    func showPlusOne() {//+1符號

        let label = UILabel()
        label.text = "+1"
        label.textColor = .systemYellow
        label.font = UIFont.boldSystemFont(ofSize: 28)
        label.sizeToFit()

        // 初始位置（木魚正中）
        let startX = woodFishImageView.center.x
        let startY = woodFishImageView.frame.minY
        label.center = CGPoint(x: startX, y: startY)
        label.alpha = 1

        view.addSubview(label)
        label.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
        // 動畫
        UIView.animate(
            withDuration: 0.15,
            delay: 0,
            options: [.curveEaseOut],
            animations: {
                label.transform = .identity
                label.center.y -= 60   // 往上飄
                label.alpha = 0        // 淡出
            },
            completion: { _ in
                label.removeFromSuperview()
            }
        )

        
        
    }

    @objc func updateWoodFish() {

        let defaults = UserDefaults.standard

        guard let typeRaw = defaults.string(
            forKey: WoodFishSetting.styleTypeKey),
              let type = WoodFishStyleType(rawValue: typeRaw)
        else { return }

        // 清掉舊漸層
        woodFishImageView.layer.sublayers?
            .filter { $0 is CAGradientLayer }
            .forEach { $0.removeFromSuperlayer() }

        switch type {

        case .solid:
            if let data = defaults.data(forKey: WoodFishSetting.solidColorKey),
               let color = try? NSKeyedUnarchiver
                    .unarchivedObject(ofClass: UIColor.self, from: data) {

                woodFishImageView.tintColor = color
            }

        case .gradient:
            let index = defaults.integer(
                forKey: WoodFishSetting.gradientIndexKey)

            let colors = WoodFishColor()
                .gradientStyles[index].colors

            let gradient = CAGradientLayer()
            gradient.frame = woodFishImageView.bounds
            gradient.colors = colors.map { $0.cgColor }

            let mask = CALayer()
            mask.frame = woodFishImageView.bounds
            mask.contents = woodFishImageView.image?.cgImage

            gradient.mask = mask
            woodFishImageView.layer.addSublayer(gradient)
            woodFishImageView.tintColor = .clear
        }
    
    }
    deinit {
        NotificationCenter.default.removeObserver(self)
    }

}
