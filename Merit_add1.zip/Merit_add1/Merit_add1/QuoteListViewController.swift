//
//  QuoteListViewController.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2025/12/20.
//語錄集
import UIKit
class QuoteListViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!

    private var quotes: [Quote] = []
    private var favoriteQuoteTexts: Set<String> = []

    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.backgroundColor = .black
        tableView.separatorColor = .darkGray

        tableView.register(
            UITableViewCell.self,
            forCellReuseIdentifier: "QuoteCell"
        )

        quotes = QuoteManager.shared.allQuotes()
        loadFavorites()

        tableView.dataSource = self
        tableView.delegate = self
    }

    private func loadFavorites() {
        let array = UserDefaults.standard.stringArray(
            forKey: "favoriteQuotes"
        ) ?? []
        favoriteQuoteTexts = Set(array)
        //print(array)
    }
    
    private func saveFavorites() {
        UserDefaults.standard.set(
            Array(favoriteQuoteTexts),
            forKey: "favoriteQuotes"
        )
        NotificationCenter.default.post(
                name: .favoritesChanged,
                object: nil
            )
    }
    func showToast(_ message: String) {
        let label = UILabel()
        label.text = message
        label.textColor = .white
        label.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 25)
        label.numberOfLines = 0
        label.alpha = 0
        label.layer.cornerRadius = 8
        label.clipsToBounds = true

        let padding: CGFloat = 16
        label.frame = CGRect(
            x: padding,
            y: view.bounds.height - 120,
            width: view.bounds.width - padding * 2,
            height: 44
        )

        view.addSubview(label)

        UIView.animate(withDuration: 0.3, animations: {
            label.alpha = 1
        }) { _ in
            UIView.animate(withDuration: 0.3, delay: 1.5, options: [], animations: {
                label.alpha = 0
            }) { _ in
                label.removeFromSuperview()
            }
        }
    }

}

extension QuoteListViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return quotes.count
    }

    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(
            withIdentifier: "QuoteCell",
            for: indexPath
        )

        let quote = quotes[indexPath.row]
        let isFavorite = QuoteManager.shared.isFavorite(text: quote.text)

        cell.backgroundColor = .black
        cell.contentView.backgroundColor = .black
        cell.textLabel?.textColor = .white
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.text = quote.text
        if isFavorite {
            cell.textLabel?.textColor = .white
        } else {
            cell.textLabel?.textColor = UIColor(white: 1.0, alpha: 0.4)
        }

        
        let imageName = isFavorite ? "star.fill" : "star"
        let starImageView = UIImageView(
            image: UIImage(systemName: imageName)
        )

        // ⭐️ 設定顏色
        starImageView.tintColor = isFavorite ? .systemYellow : .darkGray
        UIView.animate(withDuration: 0.2) {
            cell.textLabel?.alpha = isFavorite ? 1.0 : 0.5
        }

        cell.accessoryView = starImageView


        return cell
    }
    
}

extension QuoteListViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView,
                   didSelectRowAt indexPath: IndexPath) {

        let quote = quotes[indexPath.row]
        let result = QuoteManager.shared.toggleFavorite(text: quote.text)

        if result == .cannotRemoveLast {
            showToast("至少要保留一則收藏")
        }
        tableView.reloadRows(
            at: [indexPath],
            with: .automatic
        )
    }
}
