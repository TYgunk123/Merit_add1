//
//  Quote.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2025/12/20.
//
struct Quote {
    let id: Int
    let text: String
    let author: String?
    let unlockCount: Int
}
