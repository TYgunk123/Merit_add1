//
//  woodfish_color.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2025/12/19.
//

import UIKit

extension UIColor {
    convenience init(hex: String) {
        var hexString = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        if hexString.hasPrefix("#") {
            hexString.removeFirst()
        }

        var rgbValue: UInt64 = 0
        Scanner(string: hexString).scanHexInt64(&rgbValue)

        let r = CGFloat((rgbValue & 0xFF0000) >> 16) / 255
        let g = CGFloat((rgbValue & 0x00FF00) >> 8) / 255
        let b = CGFloat(rgbValue & 0x0000FF) / 255

        self.init(red: r, green: g, blue: b, alpha: 1.0)
    }
}
class WoodFishColor: UIViewController {

    @IBOutlet var circleImageViews: [UIImageView]!
    @IBOutlet weak var colorWell: UIColorWell!
    @IBOutlet weak var woodFishImageView: UIImageView!

    @IBAction func confirmButtonTapped(_ sender: UIButton) {
        let defaults = UserDefaults.standard

            if let gradientIndex = selectedGradientIndex {
                // 存漸層
                defaults.set(WoodFishStyleType.gradient.rawValue,
                             forKey: WoodFishSetting.styleTypeKey)
                defaults.set(gradientIndex,
                             forKey: WoodFishSetting.gradientIndexKey)
            } else {
                // 存單色
                let data = try? NSKeyedArchiver.archivedData(
                    withRootObject: selectedSolidColor,
                    requiringSecureCoding: true
                )
                defaults.set(WoodFishStyleType.solid.rawValue,
                             forKey: WoodFishSetting.styleTypeKey)
                defaults.set(data,
                             forKey: WoodFishSetting.solidColorKey)
            }

            // 通知主頁更新
            NotificationCenter.default.post(name: .woodFishDidChange, object: nil)

            // 切回主頁（Tab index 0）
            tabBarController?.selectedIndex = 0
    }
    struct GradientStyle {
        let colors: [UIColor]
    }
    
    let gradientStyles: [GradientStyle] = [
        GradientStyle(colors: [UIColor(hex: "#FFD26F"), UIColor(hex: "#3677FF")]),
        GradientStyle(colors: [UIColor(hex: "#A0FE65"), UIColor(hex: "#FA016D")]),
        GradientStyle(colors: [UIColor(hex: "#EEAD92"), UIColor(hex: "#6018DC")]),
        GradientStyle(colors: [UIColor(hex: "#F0FF00"), UIColor(hex: "#58CFFB")]),
        GradientStyle(colors: [UIColor(hex: "#FFA8A8"), UIColor(hex: "#FCFF00")]),
        GradientStyle(colors: [UIColor(hex: "#81FFEF"), UIColor(hex: "#F067B4")]),
        GradientStyle(colors: [UIColor(hex: "#EECE13"), UIColor(hex: "#B210FF")]),
        GradientStyle(colors: [UIColor(hex: "#FFF886"), UIColor(hex: "#F072B6")]),
        GradientStyle(colors: [UIColor(hex: "#FD6E6A"), UIColor(hex: "#FFC600")]),
        GradientStyle(colors: [UIColor(hex: "#FFF6B7"), UIColor(hex: "#F6416C")])
    ]

    var selectedGradientIndex: Int?
    var selectedSolidColor: UIColor = .white

    var woodFishGradientLayer: CAGradientLayer?


    override func viewDidLoad() {
        super.viewDidLoad()

        // 讓白色去背木魚可以被染色
        woodFishImageView.image = UIImage(named: "修改顏色示意圖.png")?
            .withRenderingMode(.alwaysTemplate)
        woodFishImageView.tintColor = .white


        // 監聽 UIColorWell 顏色變化
        colorWell.selectedColor = .white
        colorWell.addTarget(
            self,
            action: #selector(colorChanged),
            for: .valueChanged
        )

        // 設置每個圓形 UIImageView
        for imageView in circleImageViews {
            imageView.layer.cornerRadius = imageView.bounds.width / 2
            imageView.clipsToBounds = true
            imageView.layer.borderWidth = 3
            imageView.layer.borderColor = UIColor.lightGray.cgColor

            let tap = UITapGestureRecognizer(
                target: self,
                action: #selector(circleTapped(_:))
            )
            imageView.isUserInteractionEnabled = true
            imageView.addGestureRecognizer(tap)
        }
    }
    
    func loadCurrentSetting() {

        let defaults = UserDefaults.standard

        guard let typeRaw = defaults.string(
            forKey: WoodFishSetting.styleTypeKey),
              let type = WoodFishStyleType(rawValue: typeRaw)
        else {
            // 尚未設定 → 預設白色
            woodFishImageView.tintColor = .white
            return
        }

        // 清掉舊漸層
        woodFishGradientLayer?.removeFromSuperlayer()
        woodFishGradientLayer = nil

        switch type {

        case .solid:
            if let data = defaults.data(
                forKey: WoodFishSetting.solidColorKey),
               let color = try? NSKeyedUnarchiver
                    .unarchivedObject(ofClass: UIColor.self, from: data) {

                selectedGradientIndex = nil
                selectedSolidColor = color

                woodFishImageView.image = woodFishImageView.image?
                    .withRenderingMode(.alwaysTemplate)
                woodFishImageView.tintColor = color
            }

        case .gradient:
            let index = defaults.integer(
                forKey: WoodFishSetting.gradientIndexKey)

            selectedGradientIndex = index

            applyGradientToWoodFish(gradientStyles[index])
        }
    }


    // MARK: - 點擊底下圓形圖片
    @objc func circleTapped(_ sender: UITapGestureRecognizer) {
        guard
            let selectedImageView = sender.view as? UIImageView,
            let index = circleImageViews.firstIndex(of: selectedImageView)
        else { return }

        for imageView in circleImageViews {
            imageView.layer.borderColor = UIColor.lightGray.cgColor
        }
        selectedImageView.layer.borderColor =
            UIColor(red: 0.5, green: 0.7, blue: 1.0, alpha: 1.0).cgColor

        selectedGradientIndex = index          // ⭐️ 記住選到哪個漸層
        applyGradientToWoodFish(gradientStyles[index])
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadCurrentSetting()
    }

    // MARK: - UIColorWell 顏色改變
    @objc func colorChanged(_ sender: UIColorWell) {
        guard let selectedColor = sender.selectedColor else { return }

        woodFishGradientLayer?.removeFromSuperlayer()
        woodFishGradientLayer = nil

        selectedGradientIndex = nil             // ⭐️ 代表現在是單色
        selectedSolidColor = selectedColor

        woodFishImageView.image = woodFishImageView.image?
            .withRenderingMode(.alwaysTemplate)
        woodFishImageView.tintColor = selectedColor
    }


    // MARK: - 之後擴充用
    func circleAction(selected: UIImageView) {
        // TODO: 之後加入功能
        // 例如：依選到的 imageView 套預設色
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        // 確保圓形（避免 Auto Layout 尚未算好）
        for imageView in circleImageViews {
            let minSide = min(imageView.bounds.width, imageView.bounds.height)
            imageView.layer.cornerRadius = minSide / 2
        }
        
        for (index, imageView) in circleImageViews.enumerated() {

            // 清掉舊的漸層
            imageView.layer.sublayers?
                .filter { $0.name == "gradient" }
                .forEach { $0.removeFromSuperlayer() }

            let gradient = CAGradientLayer()
            gradient.name = "gradient"
            gradient.frame = imageView.bounds
            gradient.colors = gradientStyles[index].colors.map { $0.cgColor }

            // ⭐️ 用「木魚圖片」當 mask
            let maskLayer = CALayer()
            maskLayer.frame = imageView.bounds
            maskLayer.contents = imageView.image?.cgImage

            gradient.mask = maskLayer

            imageView.layer.addSublayer(gradient)
        }


    }
    
    func applyGradientToWoodFish(_ style: GradientStyle) {

        woodFishGradientLayer?.removeFromSuperlayer()

        let gradient = CAGradientLayer()
        gradient.frame = woodFishImageView.bounds
        gradient.colors = style.colors.map { $0.cgColor }

        let maskLayer = CALayer()
        maskLayer.frame = woodFishImageView.bounds
        maskLayer.contents = woodFishImageView.image?.cgImage

        gradient.mask = maskLayer

        woodFishImageView.layer.addSublayer(gradient)
        woodFishGradientLayer = gradient

        // ⭐️ 停用 tint 模式（避免誤會）
        woodFishImageView.tintColor = .clear
    }

}
