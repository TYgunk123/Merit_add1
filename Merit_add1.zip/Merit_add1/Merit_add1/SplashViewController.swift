//
//  ViewController.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2025/12/19.
//
//起始封面
import UIKit

class SplashViewController: UIViewController {
    @IBOutlet weak var quoteLabel: UILabel!
    

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            self.performSegue(withIdentifier: "goToMain", sender: nil)
        }
        
        let quote = QuoteManager.shared.randomQuote(withWoodFishCount: 1)
        quoteLabel.text = quote.text
    }
    
}
