//
//  TitleControl.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2025/12/23.
//

import UIKit
extension TitleControl: UITableViewDataSource {

    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return LevelManager.shared.levels.count
    }

    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(
            withIdentifier: "LevelCell",
            for: indexPath
        ) as! LevelCell

        let levelData = LevelManager.shared.levels[indexPath.row]
        let isCurrent = indexPath.row == LevelManager.shared.currentLevelIndex

        cell.configure(data: levelData,isCurrent: isCurrent)
        cell.backgroundColor = .black
        cell.contentView.backgroundColor = .black
        cell.textLabel?.textColor = .white
        cell.textLabel?.numberOfLines = 0
        let currentIndex = LevelManager.shared.updateindex()
        let total = LevelManager.shared.levels.count

        if indexPath.row < currentIndex {
            cell.setProgress(1.0, animated: false)
        } else if indexPath.row == currentIndex {
            cell.setProgress(1.0 / CGFloat(total), animated: true)
        } else {
            cell.setProgress(0, animated: false)
        }

      return cell
    }
}


class TitleControl: UIViewController, UITableViewDelegate {
    @IBOutlet weak var tableView: UITableView!
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableView.backgroundColor = .black
        tableView.separatorColor = .darkGray
        tableView.dataSource = self
        tableView.delegate = self

    }
    
}
