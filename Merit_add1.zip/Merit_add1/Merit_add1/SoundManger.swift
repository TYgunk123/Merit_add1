//
//  SoundManger.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2026/1/4.
//

import AVFoundation

final class SoundManager {

    static let shared = SoundManager()
    private init() {}

    private var player: AVAudioPlayer?

    func playSound(named name: String) {
        guard let url = Bundle.main.url(forResource: name, withExtension: "mp3") else {
            print(" 找不到音效：\(name)")
            return
        }

        do {
            player = try AVAudioPlayer(contentsOf: url)
            player?.prepareToPlay()
            player?.play()
        } catch {
            print(" 播放失敗：\(error)")
        }
    }
}
