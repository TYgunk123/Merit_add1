//
//  QuoteManager.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2025/12/20.
//
import Foundation

final class QuoteManager {

    static let shared = QuoteManager()
    private init() {}
    private let quotes: [Quote] = [
        Quote(id: 1, text: "一念清淨 萬善皆生", author: nil, unlockCount: 10),
        Quote(id: 2, text: "心若不動 風又奈何", author: nil, unlockCount: 20),
        Quote(id: 3, text: "日日是好日", author: nil, unlockCount: 30),
        Quote(id: 4, text: "功德在心 不在數", author: nil, unlockCount: 40),
        Quote(id: 5, text: "行穩致遠，靜水流深", author: nil, unlockCount: 50),
        Quote(id: 6, text: "不急不躁，萬事自到", author: nil, unlockCount: 60),
        Quote(id: 7, text: "心寬一寸，路寬一丈", author: nil, unlockCount: 70),
        Quote(id: 8, text: "慢慢來，比較快", author: nil, unlockCount: 80),
        Quote(id: 9, text: "知足常樂，常樂無憂", author: nil, unlockCount: 90),
        Quote(id: 10, text: "心安之處，即是歸途", author: nil, unlockCount: 100),
        Quote(id: 11, text: "萬事隨緣，不隨心亂", author: nil, unlockCount: 910),
        Quote(id: 12, text: "靜能生慧，定能生力", author: nil, unlockCount: 920),
        Quote(id: 13, text: "看淡一分，自在一分", author: nil, unlockCount: 930),
        Quote(id: 14, text: "不爭，自有天地", author: nil, unlockCount: 140),
        Quote(id: 15, text: "心不掛礙，步步生蓮", author: nil, unlockCount: 950),
        Quote(id: 16, text: "行於當下，安於此刻", author: nil, unlockCount: 960),
        Quote(id: 17, text: "心若晴朗，人生無雨", author: nil, unlockCount: 970),
        Quote(id: 18, text: "不求速成，但求真行", author: nil, unlockCount: 980),
        Quote(id: 19, text: "修行在日常，覺悟在細微", author: nil, unlockCount: 990),
        Quote(id: 20, text: "一步一腳印，功不唐捐", author: nil, unlockCount: 1000),
    ]
    var fquote: [Quote] = [Quote(id: 1, text: "一念清淨 萬善皆生", author: nil, unlockCount: 0)]

    func randomQuote(withWoodFishCount count: Int)->Quote{
        let quote=fquote.filter { count >= $0.unlockCount }
        return quote.randomElement()!
    }

    func allQuotes() -> [Quote] {
        quotes
    }
    private let favoriteKey = "favoriteQuotes"

        func favoriteQuoteTexts() -> Set<String> {
            let array = UserDefaults.standard.stringArray(
                forKey: favoriteKey
            ) ?? []
            return Set(array)
            
        }

        func toggleFavorite(text: String) -> FavoriteResult{
            var favorites = favoriteQuoteTexts()
            
            if( favorites.contains(text) ) {
                if(favorites.count == 1)
                {
                    return .cannotRemoveLast
                }
                else
                {
                    favorites.remove(text)
                }
            } else {
                favorites.insert(text)
            }

            UserDefaults.standard.set(
                Array(favorites),
                forKey: favoriteKey
            )

            // ⭐️ Manager 統一發通知
            NotificationCenter.default.post(
                name: .favoritesChanged,
                object: nil
            )

            return .success
        }
        func favoriteQuotes() {
            let favorites = favoriteQuoteTexts()
            fquote=quotes.filter { favorites.contains($0.text) }
        }
    
        func isFavorite(text: String) -> Bool {
        favoriteQuoteTexts().contains(text)
        }

        func favoriteCount() -> Int {
        favoriteQuoteTexts().count
        }
}
/*
 private let quotes: [Quote] = [
     Quote(id: 1, text: "一念清淨 萬善皆生", author: nil, unlockCount: 10),
     Quote(id: 2, text: "心若不動 風又奈何", author: nil, unlockCount: 20),
     Quote(id: 3, text: "日日是好日", author: nil, unlockCount: 30),
     Quote(id: 4, text: "功德在心 不在數", author: nil, unlockCount: 40),
     Quote(id: 5, text: "行穩致遠，靜水流深", author: nil, unlockCount: 50),
     Quote(id: 6, text: "不急不躁，萬事自到", author: nil, unlockCount: 60),
     Quote(id: 7, text: "心寬一寸，路寬一丈", author: nil, unlockCount: 70),
     Quote(id: 8, text: "慢慢來，比較快", author: nil, unlockCount: 80),
     Quote(id: 9, text: "知足常樂，常樂無憂", author: nil, unlockCount: 90),
     Quote(id: 10, text: "心安之處，即是歸途", author: nil, unlockCount: 100),
     Quote(id: 11, text: "萬事隨緣，不隨心亂", author: nil, unlockCount: 110),
     Quote(id: 12, text: "靜能生慧，定能生力", author: nil, unlockCount: 120),
     Quote(id: 13, text: "看淡一分，自在一分", author: nil, unlockCount: 130),
     Quote(id: 14, text: "不爭，自有天地", author: nil, unlockCount: 140),
     Quote(id: 15, text: "心不掛礙，步步生蓮", author: nil, unlockCount: 150),
     Quote(id: 16, text: "行於當下，安於此刻", author: nil, unlockCount: 160),
     Quote(id: 17, text: "心若晴朗，人生無雨", author: nil, unlockCount: 170),
     Quote(id: 18, text: "不求速成，但求真行", author: nil, unlockCount: 180),
     Quote(id: 19, text: "修行在日常，覺悟在細微", author: nil, unlockCount: 190),
     Quote(id: 20, text: "一步一腳印，功不唐捐", author: nil, unlockCount: 200),
 ]
 */
