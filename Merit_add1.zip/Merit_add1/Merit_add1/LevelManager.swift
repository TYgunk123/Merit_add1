//
//  LevelManager.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2026/1/1.
//

final class LevelManager {

    static let shared = LevelManager()
    private init() {}
    
    private(set) var levels: [LevelReward] = []
    var right :[String]=["一念清淨 萬善皆生","心若不動 風又奈何","日日是好日",
                         "功德在心 不在數","行穩致遠，靜水流深",
                         "不急不躁，萬事自到","心寬一寸，路寬一丈","慢慢來，比較快",  "知足常樂，常樂無憂","心安之處，即是歸途",
                         "萬事隨緣，不隨心亂","靜能生慧，定能生力",  "看淡一分，自在一分", "不爭，自有天地",
                         "心不掛礙，步步生蓮","行於當下，安於此刻",
                         "心若晴朗，人生無雨","不求速成，但求真行",
                         "修行在日常，覺悟在細微","一步一腳印，功不唐捐"]
    var currentLevelIndex: Int? {
        levels.lastIndex { $0.isUnlocked }
    }

    func setupLevels() {
        var maxLevel = right.count
        levels = (1...maxLevel).map { level in
            LevelReward(
                level: level,
                leftReward: "解鎖獎勵 ",
                rightReward: right[level-1],
                isUnlocked: level == 1
            )
            
        }
    }

    // 🔼 根據功德數更新解鎖狀態
    func updateUnlock(by meritCount: Int) {
        for i in levels.indices {
            levels[i].isUnlocked = meritCount >= levels[i].level
            //print("level \(i) is \(levels[i].isUnlocked)")
        }
        
        
    }
    func updateindex()->Int{
        return levels.lastIndex{$0.isUnlocked}!
    }
    
}
