//
//  LevelCell.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2025/12/31.
//
import UIKit

final class LevelCell: UITableViewCell {
    
    static let shared = LevelCell()

    @IBOutlet weak var levelLabel: UILabel!
    @IBOutlet weak var progressContainer: UIView!
    private let backgroundLayer = CALayer()
    private let progressLayer = CALayer()
    private let glowKey = "levelGlow"
    override func prepareForReuse() {
            super.prepareForReuse()
            stopGlow()
            setupProgress()
        }
    func configure(data: LevelReward,isCurrent: Bool) {
        levelLabel.text = (data.leftReward ?? "") + " Lv.\(data.level)      " + (data.rightReward ?? "")
        contentView.alpha = data.isUnlocked ? 1.0 : 0.5
        levelLabel.font = .systemFont(ofSize: 16, weight: .medium)
        contentView.layer.cornerRadius = 12
        contentView.layer.backgroundColor =
                    UIColor(white: 1, alpha: data.isUnlocked ? 0.08 : 0.03).cgColor
        if isCurrent {
                    startGlow()
                } else {
                    stopGlow()
                }
    }
    func startGlow() {
        if layer.animation(forKey: glowKey) != nil { return }

        layer.cornerRadius = 12
        layer.borderWidth = 3
        layer.borderColor = UIColor.systemYellow.cgColor

        let borderAnim = CABasicAnimation(keyPath: "borderColor")
        borderAnim.fromValue = UIColor.systemYellow.withAlphaComponent(0.3).cgColor
        borderAnim.toValue   = UIColor.systemYellow.cgColor
        borderAnim.duration = 0.6
        borderAnim.autoreverses = true
        borderAnim.repeatCount = .infinity

        let group = CAAnimationGroup()
        group.animations = [borderAnim]
        group.duration = 0.6
        group.autoreverses = true
        group.repeatCount = .infinity
        group.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)

        layer.add(group, forKey: glowKey)
    }
    func stopGlow() {
        layer.borderWidth = 0
        layer.shadowOpacity = 0
        layer.removeAnimation(forKey: glowKey)
    }
    private func setupProgress() {
        backgroundLayer.backgroundColor =
            UIColor(white: 1.0, alpha: 0.12).cgColor   // 淡灰底條

        progressLayer.backgroundColor =
            UIColor.systemYellow.withAlphaComponent(0.85).cgColor

        progressContainer.layer.addSublayer(backgroundLayer)
        progressContainer.layer.addSublayer(progressLayer)
    }

        override func layoutSubviews() {
            super.layoutSubviews()

            backgroundLayer.frame = progressContainer.bounds
            progressLayer.frame = CGRect(
                x: 0,
                y: progressContainer.bounds.height,
                width: progressContainer.bounds.width,
                height: 0
            )
            backgroundLayer.cornerRadius = progressContainer.bounds.width / 2
            progressLayer.cornerRadius = progressContainer.bounds.width / 2

        }

    func setProgress(_ value: CGFloat, animated: Bool) {
        let clamped = max(0, min(value, 1))
        let fullHeight = progressContainer.bounds.height
        let height = fullHeight * clamped

        let newFrame = CGRect(
            x: 0,
            y: fullHeight - height,
            width: progressContainer.bounds.width,
            height: height
        )

        if animated {
            UIView.animate(withDuration: 0.3,
                           delay: 0,
                           options: [.curveEaseOut]) {
                self.progressLayer.frame = newFrame
            }
        } else {
            progressLayer.frame = newFrame
        }
    }

}
