//
//  FavoriteResult.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2025/12/31.
//

enum FavoriteResult {
    case success
    case cannotRemoveLast
}
