//
//  WoodFishSetting.swift
//  Merit_add1
//
//  Created by EB209 雲科 on 2025/12/20.
//

import UIKit

enum WoodFishStyleType: String {
    case solid
    case gradient
}

struct WoodFishSetting {
    static let styleTypeKey = "woodFishStyleType"
    static let solidColorKey = "woodFishSolidColor"
    static let gradientIndexKey = "woodFishGradientIndex"
}

extension Notification.Name {
    static let woodFishDidChange =
        Notification.Name("woodFishDidChange")
}
